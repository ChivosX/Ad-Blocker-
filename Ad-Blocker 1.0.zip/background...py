import requests

# Add your ad-related domain patterns here
AD_DOMAINS = [
    "doubleclick.net",
    "googleadservices.com",
    "googlesyndication.com",
    # Add more ad-related domains as needed
]

def is_ad_url(url):
    for domain in AD_DOMAINS:
        if domain in url:
            return True
    return False

def block_ads(details):
    if is_ad_url(details["url"]):
        return {"cancel": True}
    return {}

def main():
    # Register the ad blocking listener
    chrome.webRequest.onBeforeRequest.addListener(
        block_ads,
        {"urls": ["<all_urls>"]},
        ["blocking"]
    )

    # Keep the extension running
    while True:
        pass

if __name__ == "__main__":
    main()
