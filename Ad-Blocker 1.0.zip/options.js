// Load saved settings
chrome.storage.sync.get({
    enableBlocking: true,
    customDomains: "",
    whitelist: "",
    blacklist: ""
  }, function(items) {
    document.getElementById('enable-blocking').checked = items.enableBlocking;
    document.getElementById('custom-domains').value = items.customDomains;
    document.getElementById('whitelist').value = items.whitelist;
    document.getElementById('blacklist').value = items.blacklist;
  });
  
  // Save settings when the form is submitted
  document.getElementById('options-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const enableBlocking = document.getElementById('enable-blocking').checked;
    const customDomains = document.getElementById('custom-domains').value;
    const whitelist = document.getElementById('whitelist').value;
    const blacklist = document.getElementById('blacklist').value;
  
    chrome.storage.sync.set({
      enableBlocking: enableBlocking,
      customDomains: customDomains,
      whitelist: whitelist,
      blacklist: blacklist
    }, function() {
      console.log('Settings saved');
    });
  });
  