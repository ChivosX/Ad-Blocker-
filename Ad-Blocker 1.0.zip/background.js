chrome.webRequest.onBeforeRequest.addListener(
    function(details) {
      // Check if ad blocking is enabled
      chrome.storage.sync.get({
        enableBlocking: true,
        customDomains: "",
        whitelist: "",
        blacklist: ""
      }, function(items) {
        if (!items.enableBlocking) {
          return;
        }
  
        // Check if the URL is on the whitelist
        if (isWhitelisted(details.url, items.whitelist)) {
          return;
        }
  
        // Check if the URL is on the blacklist
        if (isBlacklisted(details.url, items.blacklist)) {
          return { cancel: true };
        }
  
        // Check if the URL matches an ad-related domain
        if (isAdUrl(details.url, items.customDomains)) {
          return { cancel: true };
        }
      });
    },
    { urls: ["<all_urls>"] },
    ["blocking"]
  );
  
  function isWhitelisted(url, whitelist) {
    const whitelistedUrls = whitelist.split(',').map(domain => domain.trim());
    for (let i = 0; i < whitelistedUrls.length; i++) {
      if (url.indexOf(whitelistedUrls[i]) !== -1) {
        return true;
      }
    }
    return false;
  }
  
  function isBlacklisted(url, blacklist) {
    const blacklistedUrls = blacklist.split(',').map(domain => domain.trim());
    for (let i = 0; i < blacklistedUrls.length; i++) {
      if (url.indexOf(blacklistedUrls[i]) !== -1) {
        return true;
      }
    }
    return false;
  }
  
  function isAdUrl(url, customDomains) {
    const adDomains = [
      "doubleclick.net",
      "googleadservices.com",
      "googlesyndication.com"
    ];
  
    for (let i = 0; i < adDomains.length; i++) {
      if (url.indexOf(adDomains[i]) !== -1) {
        return true;
      }
    }
  
    // Check custom domains
    const customDomainsArray = customDomains.split(',').map(domain => domain.trim());
    for (let i = 0; i < customDomainsArray.length; i++) {
      if (url.indexOf(customDomainsArray[i]) !== -1) {
        return true;
      }
    }
  
    return false;
  }
  